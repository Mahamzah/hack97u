# Auto Data Engineering System

## 📌 Project Overview
This project builds an automated data engineering pipeline to process messy industrial PDF reports.

The system extracts text from PDFs, processes the data using AI, cleans it into structured format, and validates the final output.

---

## 🔄 System Workflow

PDF → OCR → AI Processing → Data Cleaning → Output Validation

1. **PDF Input**
   - Multiple industrial reports (incident reports, PVT reports, production reports)

2. **OCR Extraction**
   - Convert PDF pages into text using OCR

3. **AI Processing**
   - AI analyzes the messy text
   - Extracts key fields (e.g. temperature, pressure, dates)

4. **Data Cleaning**
   - Convert extracted data into structured format (Pandas DataFrame)
   - Handle missing values and normalize data

5. **Validation**
   - Check if output is valid and usable

---

## ⚙️ How to Run

### 1. Install Python
Python 3.9 or above is recommended

### 2. Install Required Libraries
Run this command in terminal:

    pip install pandas requests pytesseract pdf2image pillow

---

### 3. Install OCR Tools (IMPORTANT)

This project requires external OCR software:

#### (A) Install Tesseract OCR
Download and install:
https://github.com/tesseract-ocr/tesseract

After install, make sure it is added to PATH.

---

#### (B) Install Poppler (for PDF → image conversion)

Download Poppler for Windows:
https://github.com/oschwartz10612/poppler-windows/releases

After download:
- Extract the folder
- Add the `bin` folder to system PATH

---

### 4. Set API Key (Optional)

If using AI API:

PowerShell:
$env:GLM_API_KEY="sk-30b113e43d3daf703965f57383509f21d0b3445a37ebc4df"

---

### 5. Run the Project
    python main.py

---

## ⚠️ Important Notes

- If the AI API is down, the system will automatically switch to fallback mode
- OCR must be properly installed, or PDF extraction will fail
