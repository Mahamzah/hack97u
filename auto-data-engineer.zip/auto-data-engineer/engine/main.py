import os
import pandas as pd
from ai_agent import get_ai_code
from extractor import extract_text_from_pdf
from executor import run_code
from validator import validate

# =========================
# CONFIG
# =========================
USE_OCR = True
DATA_FOLDER = "../data"

# =========================
# 1. LOAD ALL FILES
# =========================
files = [f for f in os.listdir(DATA_FOLDER) if f.endswith(".pdf")]

print("\n=========================")
print("FILES FOUND")
print("=========================")
for f in files:
    print("-", f)

# =========================
# 2. OCR EXTRACTION (ALL PDFs)
# =========================
dataset_preview = ""

if USE_OCR:
    print("\n=========================")
    print("OCR EXTRACTION STARTED")
    print("=========================")

    for f in files:
        file_path = os.path.join(DATA_FOLDER, f)
        print(f"\nProcessing: {f}")

        try:
            text = extract_text_from_pdf(file_path)

            # 🔥 IMPORTANT ADDITION: include filename meaningfully
            dataset_preview += f"""

================ FILE INFO ================
FILE NAME: {f}
TASK: Extract key information and suggest clean renamed structure for this file
==========================================
{text}
"""

        except Exception as e:
            print(f"ERROR reading {f}:", e)

else:
    df = pd.read_csv("../data/messy.csv")
    dataset_preview = df.head().to_string()

# limit AI input size (important)
dataset_preview = dataset_preview[:6000]

print("\n=========================")
print("OCR PREVIEW (TRUNCATED)")
print("=========================")
print(dataset_preview[:1500])

# =========================
# 3. AUDIT LOG
# =========================
print("\n=========================")
print("INITIAL PLAN")
print("=========================")

print("- Extract text from PDFs")
print("- Identify key fields (temperature, pressure, logs)")
print("- Clean and structure data")
print("- Suggest file renaming based on content")   # 🔥 ADDED
print("- Validate output")

# =========================
# 4. AI LOOP (SELF-HEALING)
# =========================
max_retries = 3
attempt = 0
error = None
cleaned_df = None
previous_code = None

while attempt < max_retries:
    print("\n=========================")
    print(f"ATTEMPT {attempt + 1}")
    print("=========================")

    code = get_ai_code(
        dataset_preview,
        error_msg=error,
        previous_code=previous_code
    )

    print("\nAI GENERATED CODE:\n")
    print(code)

    cleaned_df, error = run_code(code, pd.DataFrame())
    previous_code = code

    if error:
        print("\nERROR ❌:", error)
    else:
        print("\nSUCCESS ✅")
        break

    attempt += 1

# =========================
# 5. FINAL OUTPUT
# =========================
print("\n=========================")
print("FINAL RESULT")
print("=========================")

if cleaned_df is None:
    print("FAILED ❌ No output generated")
else:
    valid, msg = validate(cleaned_df, cleaned_df)

    if valid:
        print("\nVALIDATION PASSED ✅")
        print(cleaned_df)
    else:
        print("\nVALIDATION FAILED ❌:", msg)
