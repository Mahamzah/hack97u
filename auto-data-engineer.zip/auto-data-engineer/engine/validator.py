def validate(original_df, cleaned_df):
    """
    Basic + robust validation for cleaned dataset
    """

    if cleaned_df is None:
        return False, "No output generated"

    if len(cleaned_df) == 0:
        return False, "All data lost"

    if len(cleaned_df.columns) == 0:
        return False, "No columns detected"

    original_rows = len(original_df)
    cleaned_rows = len(cleaned_df)

    if original_rows > 0:
        loss_ratio = abs(original_rows - cleaned_rows) / original_rows

        if loss_ratio > 0.5:
            return False, "Too many rows removed (>50%)"

    if cleaned_df.isnull().all().any():
        return False, "Column contains all NULL values"

    return True, None
