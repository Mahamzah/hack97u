def run_code(code, df):
    local_vars = {"df": df.copy()}
    
    try:
        exec(code, {}, local_vars)
        return local_vars["df"], None
    except Exception as e:
        return None, str(e)
