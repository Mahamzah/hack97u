import os
import requests

# =========================
# CONFIG
# =========================
USE_REAL_API = True
BASE_URL = "https://api.ilmu.ai/v1/chat/completions"
MODEL_NAME = "ilmu-glm-5.1"

# =========================
# MAIN FUNCTION
# =========================
def get_ai_code(dataset_preview, error_msg=None, previous_code=None):
    prompt = f"""
You are an AI data engineering assistant.
You receive messy OCR text from industrial PDF reports and CSV files.

Your task:
1. Extract structured data
2. Identify key fields (temperature, pressure, timestamps, etc.)
3. Clean and normalize data
4. Return ONLY valid Python pandas code

DATA:
{dataset_preview}
"""

    if error_msg:
        prompt += f"\nPrevious error:\n{error_msg}\n"

    if previous_code:
        prompt += f"\nPrevious code:\n{previous_code}\n"

    if not USE_REAL_API:
        return "print('mock mode')"

    return call_glm_api(prompt)

# =========================
# API CALL
# =========================
def call_glm_api(prompt):
    api_key = os.getenv("GLM_API_KEY")

    if not api_key:
        raise Exception("Missing GLM_API_KEY")

    url = BASE_URL

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 1000
    }

    print("\n[GLM] Sending request...")

    response = requests.post(
        url,
        headers=headers,
        json=payload,
        timeout=60   # 🔥 ADD THIS
    )

    if response.status_code != 200:
        raise Exception(
            f"\nGLM API ERROR\n"
            f"Status: {response.status_code}\n"
            f"Response: {response.text}"
        )

    return response.json()["choices"][0]["message"]["content"]
