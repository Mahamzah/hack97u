import pytesseract
from pdf2image import convert_from_path
from PIL import Image

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# =========================
# IMAGE OCR
# =========================
def extract_text_from_image(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text


# =========================
# PDF OCR (FULL PIPELINE)
# =========================
def extract_text_from_pdf(pdf_path):

    print("\n[OCR] Converting PDF → images...")

    pages = convert_from_path(pdf_path, dpi=300)

    full_text = ""

    for i, page in enumerate(pages):

        print(f"[OCR] Processing page {i + 1}")

        text = pytesseract.image_to_string(page)

        full_text += f"\n--- PAGE {i + 1} ---\n"
        full_text += text

    return full_text
