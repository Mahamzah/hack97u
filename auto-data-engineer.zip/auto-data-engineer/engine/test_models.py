import os
import requests

api_key = os.getenv("GLM_API_KEY")

url = "https://api.ilmu.ai/v1/models"

headers = {
    "Authorization": f"Bearer {api_key}"
}

response = requests.get(url, headers=headers)

print(response.status_code)
print(response.text)
